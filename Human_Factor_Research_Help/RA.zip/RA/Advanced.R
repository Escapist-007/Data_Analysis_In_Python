  library(chron)
  library(lubridate)
  library(openxlsx)
  
  overallpostures <- read.csv("overall postures 11-16A.csv", header = TRUE)
  names(overallpostures)[1] <- "Posture Code"
  names(overallpostures)[5] <- "Task"
  overallpostures <- overallpostures[order(overallpostures$`Posture Code`),]
  head(overallpostures)
  tail(overallpostures) 
  
  Task_1 <- subset(overallpostures, Task == 'TVH (Transvaginal hysterectomy)' & Duration != "00:00")
  Task_2 <- subset(overallpostures, Task == 'USLS (Uterosacral ligament suspension)'& Duration != "00:00")
  Task_3 <- subset(overallpostures, Task == 'AR (Anterior repair)'& Duration != "00:00")
  Task_4 <- subset(overallpostures, Task == 'USLS+AR'& Duration != "00:00")
  Task_5 <- subset(overallpostures, Task == 'PR (Posterior repair)'& Duration != "00:00")
  Task_6 <- subset(overallpostures, Task == 'Sling (Midurethral synthetic sling)'& Duration != "00:00")
  Task_7 <- subset(overallpostures, Task == 'Cysto (Cystoscopy)')
  Task_8 <- subset(overallpostures, Task == 'BSO (Biateral salpingo-oophrectomy)'& Duration != "00:00")
  Task_9 <- subset(overallpostures, Task == 'Unilateral salpingo-oopherectomy'& Duration != "00:00")
  Task_10 <- subset(overallpostures, Task == 'Bilateral salpingectomy'& Duration != "00:00")
  Task_11 <- subset(overallpostures, Task == 'Unilateral salpingectomy'& Duration != "00:00")
  Task_12 <- subset(overallpostures, Task == 'Total colpocleisis'& Duration != "00:00")
  Task_13 <- subset(overallpostures, Task == 'Bartholin cyst marsupialization'& Duration != "00:00")
  Task_14 <- subset(overallpostures, Task == 'Attachement of vaginal mesh'& Duration != "00:00")
  Task_15 <- subset(overallpostures, Task == 'Laparoscopic procedure'& Duration != "00:00")
  overallpostures <- subset(overallpostures, Duration != "00:00")
  
  max_of_posturecode <- max(overallpostures$`Posture Code`)
  max_of_Task_1 <- max(Task_1$`Posture Code`)
  max_of_Task_2 <- max(Task_2$`Posture Code`)
  max_of_Task_3 <- max(Task_3$`Posture Code`)
  max_of_Task_4 <- max(Task_4$`Posture Code`)
  max_of_Task_5 <- max(Task_5$`Posture Code`)
  max_of_Task_6 <- max(Task_6$`Posture Code`)
  max_of_Task_7 <- max(Task_7$`Posture Code`)
  max_of_Task_8 <- max(Task_8$`Posture Code`)
  max_of_Task_9 <- max(Task_9$`Posture Code`)
  max_of_Task_10 <- max(Task_10$`Posture Code`)
  max_of_Task_11 <- max(Task_11$`Posture Code`)
  max_of_Task_12 <- max(Task_12$`Posture Code`)
  max_of_Task_13 <- max(Task_13$`Posture Code`)
  max_of_Task_14 <- max(Task_14$`Posture Code`)
  max_of_Task_15 <- max(Task_15$`Posture Code`)
  
  
  
  t <- tabulate(overallpostures$`Posture Code`)
  t1 <- tabulate(Task_1$`Posture Code`)
  t2 <- tabulate(Task_2$`Posture Code`)
  t3 <- tabulate(Task_3$`Posture Code`)
  t4 <- tabulate(Task_4$`Posture Code`)
  t5 <- tabulate(Task_5$`Posture Code`)
  t6 <- tabulate(Task_6$`Posture Code`)
  t7 <- tabulate(Task_7$`Posture Code`)
  t8 <- tabulate(Task_8$`Posture Code`)
  t9 <- tabulate(Task_9$`Posture Code`)
  t10 <- tabulate(Task_10$`Posture Code`)
  t11 <- tabulate(Task_11$`Posture Code`)
  t12 <- tabulate(Task_12$`Posture Code`)
  t13 <- tabulate(Task_13$`Posture Code`)
  t14 <- tabulate(Task_14$`Posture Code`)
  t15 <- tabulate(Task_15$`Posture Code`)
  
  final_dat <- data.frame(Var1 = 1:max_of_posturecode, Freq = 0)
  final_dat$Freq <- t
  
  final_dat_1 <- data.frame(Posture_code = 1:max_of_Task_1, Freq = 0)
  final_dat_1$Freq <- t1
  
  final_dat_2 <- data.frame(Posture_code = 1:max_of_Task_2, Freq = 0)
  final_dat_2$Freq <- t2
  
  final_dat_3 <- data.frame(Posture_code = 1:max_of_Task_3, Freq = 0)
  final_dat_3$Freq <- t3
  
  final_dat_4 <- data.frame(Posture_code = 1:max_of_Task_4, Freq = 0)
  final_dat_4$Freq <- t4
  
  final_dat_5 <- data.frame(Posture_code = 1:max_of_Task_5, Freq = 0)
  final_dat_5$Freq <- t5
  
  final_dat_6 <- data.frame(Posture_code = 1:max_of_Task_6, Freq = 0)
  final_dat_6$Freq <- t6
  
  final_dat_7 <- data.frame(Posture_code = 1:max_of_Task_7, Freq = 0)
  final_dat_7$Freq <- t7
  
  final_dat_8 <- data.frame(Posture_code = 1:max_of_Task_8, Freq = 0)
  final_dat_8$Freq <- t8
  
  final_dat_9 <- data.frame(Posture_code = 1:max_of_Task_9, Freq = 0)
  final_dat_9$Freq <- t9
  
  final_dat_10 <- data.frame(Posture_code = 1:max_of_Task_10, Freq = 0)
  final_dat_10$Freq <- t10
  
  final_dat_11 <- data.frame(Posture_code = 1:max_of_Task_11, Freq = 0)
  final_dat_11$Freq <- t11
  
  final_dat_12 <- data.frame(Posture_code = 1:max_of_Task_12, Freq = 0)
  final_dat_12$Freq <- t12
  
  final_dat_13 <- data.frame(Posture_code = 1:max_of_Task_13, Freq = 0)
  final_dat_13$Freq <- t13
  
  final_dat_14 <- data.frame(Posture_code = 1:max_of_Task_14, Freq = 0)
  final_dat_14$Freq <- t14
  
  final_dat_15 <- data.frame(Posture_code = 1:max_of_Task_15, Freq = 0)
  final_dat_15$Freq <- t15
  
  
  ##Checking structure of Posture Code and converting it to character for implementing strsplit
  overallpostures$Duration <-  as.character(overallpostures$Duration)
  overallpostures$Duration <- strsplit(overallpostures$Duration, ":")
  overallpostures$Duration
  
  #Checking what happens after applying strsplit
  str(overallpostures$Duration)
  length(overallpostures$Duration)
  head(overallpostures$Duration)
  overallpostures$Duration[[1]][2]
  
  #converting duration to seconds
  a <- c(1:length(overallpostures$Duration))
  b <- c(1:length(overallpostures$Duration))
  
  for(i in 1:length(overallpostures$Duration)) {
    a[i] <- overallpostures$Duration[[i]][1]
    b[i] <- overallpostures$Duration[[i]][2]
  }
  
  a <-  as.numeric(a)
  b <-  as.numeric(b)
  
  
  overallpostures$Duration <- a*60 +b
  overallpostures$Duration[2]
  
  
  Posturecodesum <- c(1:max_of_posturecode)
  for(i in 1:max_of_posturecode) {
    Posturecodesum[i] <- sum(overallpostures$Duration[overallpostures$`Posture Code` == i])
  }
  Posturecodesum
  
  Posturecodesum1 <- c(1:max_of_Task_1)
  for(i in 1:max_of_Task_1) {
    Posturecodesum1[i] <- sum(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'TVH (Transvaginal hysterectomy)'])
  }
  Posturecodesum1
  
  Posturecodesum2 <- c(1:max_of_Task_2)
  for(i in 1:max_of_Task_2) {
    Posturecodesum2[i] <- sum(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'USLS (Uterosacral ligament suspension)'])
  }
  Posturecodesum2
  
  Posturecodesum3 <- c(1:max_of_Task_3)
  for(i in 1:max_of_Task_3) {
    Posturecodesum3[i] <- sum(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'AR (Anterior repair)'])
  }
  Posturecodesum3
  
  Posturecodesum4 <- c(1:max_of_Task_4)
  for(i in 1:max_of_Task_4) {
    Posturecodesum4[i] <- sum(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'USLS+AR'])
  }
  Posturecodesum4
  
  Posturecodesum5 <- c(1:max_of_Task_5)
  for(i in 1:max_of_Task_5) {
    Posturecodesum5[i] <- sum(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'PR (Posterior repair)'])
  }
  Posturecodesum5
  
  Posturecodesum6 <- c(1:max_of_Task_6)
  for(i in 1:max_of_Task_6) {
    Posturecodesum6[i] <- sum(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'Sling (Midurethral synthetic sling)'])
  }
  Posturecodesum6
  
  Posturecodesum7 <- c(1:max_of_Task_7)
  for(i in 1:max_of_Task_7) {
    Posturecodesum7[i] <- sum(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'Cysto (Cystoscopy)'])
  }
  Posturecodesum7
  
  Posturecodesum8 <- c(1:max_of_Task_8)
  for(i in 1:max_of_Task_8) {
    Posturecodesum8[i] <- sum(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'BSO (Biateral salpingo-oophrectomy)'])
  }
  Posturecodesum8
  
  Posturecodesum9 <- c(1:max_of_Task_9)
  for(i in 1:max_of_Task_9) {
    Posturecodesum9[i] <- sum(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'Unilateral salpingo-oopherectomy'])
  }
  Posturecodesum9
  
  Posturecodesum10 <- c(1:max_of_Task_10)
  for(i in 1:max_of_Task_10) {
    Posturecodesum10[i] <- sum(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'Bilateral salpingectomy'])
  }
  Posturecodesum10
  
  Posturecodesum11 <- c(1:max_of_Task_11)
  for(i in 1:max_of_Task_11) {
    Posturecodesum11[i] <- sum(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'Unilateral salpingectomy'])
  }
  Posturecodesum11
  
  Posturecodesum12 <- c(1:max_of_Task_12)
  for(i in 1:max_of_Task_12) {
    Posturecodesum12[i] <- sum(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'Total colpocleisis'])
  }
  Posturecodesum12
  
  Posturecodesum13 <- c(1:max_of_Task_13)
  for(i in 1:max_of_Task_13) {
    Posturecodesum13[i] <- sum(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'Bartholin cyst marsupialization'])
  }
  Posturecodesum13
  
  Posturecodesum14 <- c(1:max_of_Task_14)
  for(i in 1:max_of_Task_14) {
    Posturecodesum14[i] <- sum(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'Attachement of vaginal mesh'])
  }
  Posturecodesum14
  
  Posturecodesum15 <- c(1:max_of_Task_15)
  for(i in 1:max_of_Task_15) {
    Posturecodesum15[i] <- sum(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'Laparoscopic procedure'])
  }
  Posturecodesum15
  
  
  
  minPosturecode <- c(1:max_of_posturecode)
  maxPosturecode <- c(1:max_of_posturecode)
  suppressWarnings(
    for(i in 1:max_of_posturecode) {
      minPosturecode[i] <- min(overallpostures$Duration[overallpostures$`Posture Code` == i],na.rm=TRUE)
      maxPosturecode[i] <- max(overallpostures$Duration[overallpostures$`Posture Code` == i],na.rm=TRUE)
    }
  )
  minPosturecode
  maxPosturecode
  
  minPosturecode1 <- c(1:max_of_Task_1)
  maxPosturecode1 <- c(1:max_of_Task_1)
  suppressWarnings(
    for(i in 1:max_of_Task_1) {
      minPosturecode1[i] <- min(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'TVH (Transvaginal hysterectomy)' & overallpostures$Duration != 0],na.rm=TRUE)
      maxPosturecode1[i] <- max(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'TVH (Transvaginal hysterectomy)'],na.rm=TRUE)
    }
  )
  minPosturecode1
  maxPosturecode1
  
  minPosturecode2 <- c(1:max_of_Task_2)
  maxPosturecode2 <- c(1:max_of_Task_2)
  suppressWarnings(
    for(i in 1:max_of_Task_2) {
      minPosturecode2[i] <- min(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'USLS (Uterosacral ligament suspension)' & overallpostures$Duration != 0],na.rm=TRUE)
      maxPosturecode2[i] <- max(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'USLS (Uterosacral ligament suspension)'],na.rm=TRUE)
    }
  )
  minPosturecode2
  maxPosturecode2
  
  
  minPosturecode3 <- c(1:max_of_Task_3)
  maxPosturecode3 <- c(1:max_of_Task_3)
  suppressWarnings(
    for(i in 1:max_of_Task_3) {
      minPosturecode3[i] <- min(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'AR (Anterior repair)' & overallpostures$Duration != 0],na.rm=TRUE)
      maxPosturecode3[i] <- max(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'AR (Anterior repair)'],na.rm=TRUE)
    }
  )
  minPosturecode3
  maxPosturecode3
  
  
  minPosturecode4 <- c(1:max_of_Task_4)
  maxPosturecode4 <- c(1:max_of_Task_4)
  suppressWarnings(
    for(i in 1:max_of_Task_4) {
      minPosturecode4[i] <- min(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'USLS+AR' & overallpostures$Duration != 0],na.rm=TRUE)
      maxPosturecode4[i] <- max(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'USLS+AR'],na.rm=TRUE)
    }
  )
  minPosturecode4
  maxPosturecode4
  
  
  minPosturecode5 <- c(1:max_of_Task_5)
  maxPosturecode5 <- c(1:max_of_Task_5)
  suppressWarnings(
    for(i in 1:max_of_Task_5) {
      minPosturecode5[i] <- min(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'PR (Posterior repair)' & overallpostures$Duration != 0],na.rm=TRUE)
      maxPosturecode5[i] <- max(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'PR (Posterior repair)'],na.rm=TRUE)
    }
  )
  minPosturecode5
  maxPosturecode5
  
  
  minPosturecode6 <- c(1:max_of_Task_6)
  maxPosturecode6 <- c(1:max_of_Task_6)
  suppressWarnings(
    for(i in 1:max_of_Task_6) {
      minPosturecode6[i] <- min(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'Sling (Midurethral synthetic sling)' & overallpostures$Duration != 0],na.rm=TRUE)
      maxPosturecode6[i] <- max(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'Sling (Midurethral synthetic sling)'],na.rm=TRUE)
    }
  )
  minPosturecode6
  maxPosturecode6
  
  
  minPosturecode7 <- c(1:max_of_Task_7)
  maxPosturecode7 <- c(1:max_of_Task_7)
  suppressWarnings(
    for(i in 1:max_of_Task_7) {
      minPosturecode7[i] <- min(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'Cysto (Cystoscopy)' & overallpostures$Duration != 0],na.rm=TRUE)
      maxPosturecode7[i] <- max(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'Cysto (Cystoscopy)'],na.rm=TRUE)
    }
  )
  minPosturecode7
  maxPosturecode7
  
  
  minPosturecode8 <- c(1:max_of_Task_8)
  maxPosturecode8 <- c(1:max_of_Task_8)
  suppressWarnings(
    for(i in 1:max_of_Task_8) {
      minPosturecode8[i] <- min(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'BSO (Biateral salpingo-oophrectomy)' & overallpostures$Duration != 0],na.rm=TRUE)
      maxPosturecode8[i] <- max(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'BSO (Biateral salpingo-oophrectomy)'],na.rm=TRUE)
    }
  )
  minPosturecode8
  maxPosturecode8
  
  
  minPosturecode9 <- c(1:max_of_Task_9)
  maxPosturecode9 <- c(1:max_of_Task_9)
  suppressWarnings(
    for(i in 1:max_of_Task_9) {
      minPosturecode9[i] <- min(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'Unilateral salpingo-oopherectomy' & overallpostures$Duration != 0],na.rm=TRUE)
      maxPosturecode9[i] <- max(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'Unilateral salpingo-oopherectomy'],na.rm=TRUE)
    }
  )
  minPosturecode9
  maxPosturecode9
  
  
  minPosturecode10 <- c(1:max_of_Task_10)
  maxPosturecode10 <- c(1:max_of_Task_10)
  suppressWarnings(
    for(i in 1:max_of_Task_10) {
      minPosturecode10[i] <- min(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'Bilateral salpingectomy' & overallpostures$Duration != 0],na.rm=TRUE)
      maxPosturecode10[i] <- max(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'Bilateral salpingectomy'],na.rm=TRUE)
    }
  )
  minPosturecode10
  maxPosturecode10
  
  
  minPosturecode11 <- c(1:max_of_Task_11)
  maxPosturecode11 <- c(1:max_of_Task_11)
  suppressWarnings(
    for(i in 1:max_of_Task_11) {
      minPosturecode11[i] <- min(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'Unilateral salpingectomy' & overallpostures$Duration != 0],na.rm=TRUE)
      maxPosturecode11[i] <- max(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'Unilateral salpingectomy'],na.rm=TRUE)
    }
  )
  minPosturecode11
  maxPosturecode11
  
  
  minPosturecode12 <- c(1:max_of_Task_12)
  maxPosturecode12 <- c(1:max_of_Task_12)
  suppressWarnings(
    for(i in 1:max_of_Task_12) {
      minPosturecode12[i] <- min(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'Total colpocleisis' & overallpostures$Duration != 0],na.rm=TRUE)
      maxPosturecode12[i] <- max(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'Total colpocleisis'],na.rm=TRUE)
    }
  )
  minPosturecode12
  maxPosturecode12
  
  
  minPosturecode13 <- c(1:max_of_Task_13)
  maxPosturecode13 <- c(1:max_of_Task_13)
  suppressWarnings(
    for(i in 1:max_of_Task_13) {
      minPosturecode13[i] <- min(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'Bartholin cyst marsupialization' & overallpostures$Duration != 0],na.rm=TRUE)
      maxPosturecode13[i] <- max(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'Bartholin cyst marsupialization'],na.rm=TRUE)
    }
  )
  minPosturecode13
  maxPosturecode13
  
  
  minPosturecode14 <- c(1:max_of_Task_14)
  maxPosturecode14 <- c(1:max_of_Task_14)
  suppressWarnings(
    for(i in 1:max_of_Task_14) {
      minPosturecode14[i] <- min(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'Attachement of vaginal mesh' & overallpostures$Duration != 0],na.rm=TRUE)
      maxPosturecode14[i] <- max(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'Attachement of vaginal mesh'],na.rm=TRUE)
    }
  )
  minPosturecode14
  maxPosturecode14
  
  minPosturecode15 <- c(1:max_of_Task_15)
  maxPosturecode15 <- c(1:max_of_Task_15)
  suppressWarnings(
    for(i in 1:max_of_Task_15) {
      minPosturecode15[i] <- min(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'Laparoscopic procedure' & overallpostures$Duration != 0],na.rm=TRUE)
      maxPosturecode15[i] <- max(overallpostures$Duration[overallpostures$`Posture Code` == i & overallpostures$Task == 'Laparoscopic procedure'],na.rm=TRUE)
    }
  )
  minPosturecode15
  maxPosturecode15
  
  
  
  
  
  Results <- data.frame(Posturecodesum, minPosturecode, maxPosturecode)
  Results1 <- data.frame(Posturecodesum1, minPosturecode1, maxPosturecode1)
  Results2 <- data.frame(Posturecodesum2, minPosturecode2, maxPosturecode2)
  Results3 <- data.frame(Posturecodesum3, minPosturecode3, maxPosturecode3)
  Results4 <- data.frame(Posturecodesum4, minPosturecode4, maxPosturecode4)
  Results5 <- data.frame(Posturecodesum5, minPosturecode5, maxPosturecode5)
  Results6 <- data.frame(Posturecodesum6, minPosturecode6, maxPosturecode6)
  Results7 <- data.frame(Posturecodesum7, minPosturecode7, maxPosturecode7)
  Results8 <- data.frame(Posturecodesum8, minPosturecode8, maxPosturecode8)
  Results9 <- data.frame(Posturecodesum9, minPosturecode9, maxPosturecode9)
  Results10 <- data.frame(Posturecodesum10, minPosturecode10, maxPosturecode10)
  Results11 <- data.frame(Posturecodesum11, minPosturecode11, maxPosturecode11)
  Results12 <- data.frame(Posturecodesum12, minPosturecode12, maxPosturecode12)
  Results13 <- data.frame(Posturecodesum13, minPosturecode13, maxPosturecode13)
  Results14 <- data.frame(Posturecodesum14, minPosturecode14, maxPosturecode14)
  Results15 <- data.frame(Posturecodesum15, minPosturecode15, maxPosturecode15)
  
  
  
  Final <- cbind(final_dat,Results)
  Final1 <- cbind(final_dat_1,Results1)
  Final2 <- cbind(final_dat_2,Results2)
  Final3 <- cbind(final_dat_3,Results3)
  Final4 <- cbind(final_dat_4,Results4)
  Final5 <- cbind(final_dat_5,Results5)
  Final6 <- cbind(final_dat_6,Results6)
  Final7 <- cbind(final_dat_7,Results7)
  Final8 <- cbind(final_dat_8,Results8)
  Final9 <- cbind(final_dat_9,Results9)
  Final10 <- cbind(final_dat_10,Results10)
  Final11 <- cbind(final_dat_11,Results11)
  Final12 <- cbind(final_dat_12,Results12)
  Final13 <- cbind(final_dat_13,Results13)
  Final14 <- cbind(final_dat_14,Results14)
  Final15 <- cbind(final_dat_15,Results15)
  
  
  
  names(Final)[3] <- 'Duration(s)'
  names(Final)[4] <- 'Min Duration(s)'
  names(Final)[5] <- 'Max Duration(s)'
  
  names(Final1)[3] <- 'Duration(s)'
  names(Final1)[4] <- 'Min Duration(s)'
  names(Final1)[5] <- 'Max Duration(s)'
  
  names(Final2)[3] <- 'Duration(s)'
  names(Final2)[4] <- 'Min Duration(s)'
  names(Final2)[5] <- 'Max Duration(s)'
  
  names(Final3)[3] <- 'Duration(s)'
  names(Final3)[4] <- 'Min Duration(s)'
  names(Final3)[5] <- 'Max Duration(s)'
  
  names(Final4)[3] <- 'Duration(s)'
  names(Final4)[4] <- 'Min Duration(s)'
  names(Final4)[5] <- 'Max Duration(s)'
  
  names(Final5)[3] <- 'Duration(s)'
  names(Final5)[4] <- 'Min Duration(s)'
  names(Final5)[5] <- 'Max Duration(s)'
  
  names(Final6)[3] <- 'Duration(s)'
  names(Final6)[4] <- 'Min Duration(s)'
  names(Final6)[5] <- 'Max Duration(s)'
  
  names(Final7)[3] <- 'Duration(s)'
  names(Final7)[4] <- 'Min Duration(s)'
  names(Final7)[5] <- 'Max Duration(s)'
  
  names(Final8)[3] <- 'Duration(s)'
  names(Final8)[4] <- 'Min Duration(s)'
  names(Final8)[5] <- 'Max Duration(s)'
  
  names(Final9)[3] <- 'Duration(s)'
  names(Final9)[4] <- 'Min Duration(s)'
  names(Final9)[5] <- 'Max Duration(s)'
  
  names(Final10)[3] <- 'Duration(s)'
  names(Final10)[4] <- 'Min Duration(s)'
  names(Final10)[5] <- 'Max Duration(s)'
  
  names(Final11)[3] <- 'Duration(s)'
  names(Final11)[4] <- 'Min Duration(s)'
  names(Final11)[5] <- 'Max Duration(s)'
  
  names(Final12)[3] <- 'Duration(s)'
  names(Final12)[4] <- 'Min Duration(s)'
  names(Final12)[5] <- 'Max Duration(s)'
  
  names(Final13)[3] <- 'Duration(s)'
  names(Final13)[4] <- 'Min Duration(s)'
  names(Final13)[5] <- 'Max Duration(s)'
  
  names(Final14)[3] <- 'Duration(s)'
  names(Final14)[4] <- 'Min Duration(s)'
  names(Final14)[5] <- 'Max Duration(s)'
  
  names(Final15)[3] <- 'Duration(s)'
  names(Final15)[4] <- 'Min Duration(s)'
  names(Final15)[5] <- 'Max Duration(s)'
  
  #write.xlsx(Final, "0.xlsx")
  #write.xlsx(Final1, "1.xlsx")
  #write.xlsx(Final2, '2.xlsx')
  #write.xlsx(Final3, '3.xlsx')
  #write.xlsx(Final4, '4.xlsx')
  #write.xlsx(Final5, '5.xlsx')
  #write.xlsx(Final6, '6.xlsx')
  write.xlsx(Final7, '7.xlsx')
  #write.xlsx(Final8, '8.xlsx')
  #write.xlsx(Final9, '9.xlsx')
  #write.xlsx(Final10, '10.xlsx')
  #write.xlsx(Final11, '11.xlsx')
  #write.xlsx(Final12, '12.xlsx')
  #write.xlsx(Final13, '13.xlsx')
  #write.xlsx(Final14, '14.xlsx')
  #write.xlsx(Final15, '15.xlsx')
  
  
  
