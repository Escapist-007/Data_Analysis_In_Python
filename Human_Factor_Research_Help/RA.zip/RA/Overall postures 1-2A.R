library(chron)
library(lubridate)
library(openxlsx)
library(plyr)


#Reading "overall postures" csv file
overallpostures <- read.csv("Overall postures 13-17P.csv", header = TRUE, sep=",", skipNul = TRUE)
names(overallpostures)[1] <- "Posture Code"
names(overallpostures)[4] <- "Duration"

complete.cases(overallpostures)
#Checking head and tail 
head(overallpostures)
tail(overallpostures)
summary(overallpostures)

#Checking and correcting header
#names(overallpostures)[2]


#Checking required columns
overallpostures[c(415:435), c(1,4,5)]
#head(overallpostures[, c(1,4,5)])
#tail(overallpostures[, c(1,4,5)])
overallpostures <- overallpostures[order(overallpostures$`Posture Code`),]
 
overallpostures[c(20:10), c(1,4,5)]
#head(overallpostures[, c(1,4,5)])
#tail(overallpostures[, c(1,4,5)])
max((overallpostures$`Posture Code`))

 
#Checking structure of Posture Code and converting it to character
#str(overallpostures$`Posture Code`)
max_of_posturecode <- max(overallpostures$`Posture Code`)
str(overallpostures$`Posture Code`)
t <- tabulate(overallpostures$`Posture Code`)
sum(table(overallpostures$`Posture Code`))



final_dat <- data.frame(Var1 = 1:max_of_posturecode, Freq = 0)
final_dat$Freq <- t

View(final_dat)



#overallpostures$`Posture Code` <-  as.character(overallpostures$`Posture Code`)


##Checking structure of Posture Code and converting it to character for implementing strsplit
summary(overallpostures$Duration)
str(overallpostures$Duration)
overallpostures$Duration <-  as.character(overallpostures$Duration)
overallpostures$Duration <- strsplit(overallpostures$Duration, ":")
overallpostures$Duration

#Checking what happens after applying strsplit
str(overallpostures$Duration)
length(overallpostures$Duration)
head(overallpostures$Duration)
overallpostures$Duration[[1]][2]

#converting duration to seconds
a <- c(1:length(overallpostures$Duration))
b <- c(1:length(overallpostures$Duration))

for(i in 1:length(overallpostures$Duration)) {
  a[i] <- overallpostures$Duration[[i]][1]
  b[i] <- overallpostures$Duration[[i]][2]
}
a[497]
str(a)

b[497]
str(b)

a <-  as.numeric(a)
b <-  as.numeric(b)

a[445]
str(a)

b[445]
str(b)

overallpostures$Duration <- a*60 +b
overallpostures$Duration[2]


Posturecodesum <- c(1:max_of_posturecode)
for(i in 1:max_of_posturecode) {
  Posturecodesum[i] <- sum(overallpostures$Duration[overallpostures$`Posture Code` == i])
}
Posturecodesum

(overallpostures$Duration[overallpostures$`Posture Code` == 30])

minPosturecode <- c(1:max_of_posturecode)
maxPosturecode <- c(1:max_of_posturecode)
suppressWarnings(
  for(i in 1:max_of_posturecode) {
    minPosturecode[i] <- min(overallpostures$Duration[overallpostures$`Posture Code` == i],na.rm=TRUE)
    maxPosturecode[i] <- max(overallpostures$Duration[overallpostures$`Posture Code` == i],na.rm=TRUE)
  }
)
minPosturecode
maxPosturecode



Results <- data.frame(Posturecodesum,minPosturecode,maxPosturecode)
Final <- cbind(final_dat,Results)
names(Final)[3] <- 'Duration(s)'
names(Final)[4] <- 'Min Duration(s)'
names(Final)[5] <- 'Max Duration(s)'
names(Final)[1] <- 'Posture Code'
edit(Final)

write.xlsx(Final, "13-17P_Results.xlsx")







